let email = document.getElementById("email");
let pwd = document.getElementById("pwd");
    
        
    //email validation//

        function validate() {
                  
        let emailcheck = /^([A-Za-z0-9\.-]+)@([A-Za-z0-9\-]+).([a-z]{2,3})(.[a-z]{2,3}?)$/;
        let pwdcheck = /^(?=.*[0-9])(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$/;


            if (emailcheck.test(email.value)){
                document.getElementById('emailerror').innerHTML="";
                }

            else{
                document.getElementById('emailerror').innerHTML="** email is invalid**";
                 return false;
                }

                 //password validation//

            if (pwdcheck.test(pwd.value)){
                document.getElementById('pwds').innerHTML="";
                }

            else{
                document.getElementById('pwds').innerHTML="**password is not valid**";
                 return false;
                }
}